/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/22 10:57:07 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/22 11:21:01 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_factorial(int nb)
{
	int	num;
	int	cont;

	num = 1;
	if (nb < 0)
		num = 0;
	else if ((nb == 0) || (nb == 1))
	{
		num = 1;
	}
	else
	{
		cont = 1;
		while (cont <= nb)
		{
			num = num * cont;
			cont++;
		}
	}
	return (num);
}
