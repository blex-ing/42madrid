/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/22 11:30:57 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/22 23:59:27 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_power(int nb, int power)
{
	int	num;
	int	cont;

	num = 1;
	if (power < 0)
	{
		num = 0;
	}
	else if (power == 0)
	{
		num = 1;
	}
	else
	{
		cont = 1;
		while (cont <= power)
		{
			num = num * nb;
			cont++;
		}
	}
	return (num);
}
