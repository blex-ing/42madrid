/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42madrid>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/07 17:15:36 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/08 18:09:26 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_ultimate_div_mod(int *a, int *b)
{
	int	aux;

	aux = *a;
	*a = aux / *b;
	*b = aux % *b;
}

int	main(void)
{
	int	v1;
	int v2;

	v1 = 23;
	v2 = 10;

	ft_ultimate_div_mod(&v1, &v2);

	printf("\n resultado de a division: %d y resto: %d",v1,v2);
}
