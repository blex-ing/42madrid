/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_swap.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42madrid>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/07 17:03:58 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/08 17:38:59 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void ft_swap(int *a, int *b)
{
	int aux;

	aux = *a;
	*a = *b;
	*b = aux;
}

int main (void)
{
	int	valor1;
	int valor2;
	
	valor1 = 0;
	valor2 = 20;

	ft_swap(&valor1, &valor2);

	printf("valores actualizados V1: %d , V2:%d \n", valor1, valor2);
}
