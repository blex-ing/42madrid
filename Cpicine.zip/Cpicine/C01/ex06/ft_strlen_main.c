/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42madrid>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/07 17:59:53 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/08 18:28:27 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

int	ft_strlen(char *str)
{
	int i;

	i = 0;
	if (str == NULL)
	{
		return (0);
	}
	else
	{
		while (str[i] != '\0')
		{
			i++;
		}
		return (i);
	}
}

int main(void)
{
	char str [] = "Hola munndo";

	printf("tamaño: %d" , ft_strlen(str));
}
