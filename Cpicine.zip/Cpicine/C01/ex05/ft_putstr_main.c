/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42madrid>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/07 17:21:06 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/08 18:22:40 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putstr(char *str)
{
	int		i;
	char	aux;

	i = 0;
	if (str == NULL)
	{
		return ;
	}
	else
	{
		while (str[i] != '\0')
		{
			aux = str[i];
			write(1, &aux, 1);
			i++;
		}
	}
}

int	main(void)
{
	int 	cont;
	char 	temp;
	char str[] = "probando main";

	cont = 0;
	ft_putstr(str);

	while(str[cont]!= '\0')
	{
		temp = str[cont];
		write(1, &temp, 1);
		cont++;
	}
}
