/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42madrid>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/07 17:21:06 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/08 18:09:45 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putstr(char *str)
{
	int		i;
	char	aux;

	i = 0;
	if (str == NULL)
	{
		return ;
	}
	else
	{
		while (str[i] != '\0')
		{
			aux = str[i];
			write(1, &aux, 1);
			i++;
		}
	}
}
