/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42madrid>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/09 11:41:38 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/09 13:22:44 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_swap(int *a, int *b)
{
	int	temp;

	temp = *a;
	*a = *b;
	*b = temp;
}

void	ft_sort_int_tab(int *tab, int size)
{
	int	first;
	int	last;
	int	cont;

	first = 0;
	last = size - 1;
	cont = 0;
	while (cont < size -1)
	{
		while (first < last)
		{
			if (tab[first] > tab[first + 1])
			{
				ft_swap(&tab[first], &tab[first + 1]);
			}
			first++;
		}
		cont++;
		first = 0;
	}
}
