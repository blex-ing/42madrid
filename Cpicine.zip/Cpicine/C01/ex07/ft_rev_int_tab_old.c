/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42madrid>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/08 13:12:55 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/08 13:55:24 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void ft_rev_int_tab(int *tab, int size)
{
	int		*x;
	int		*y;
	char	aux;
    int     aux1;
	int 	i;
    
    x = tab;
    y = tab + size -1;

	while ( x < y)
	{
		aux1 = *x;
		*x = *y;
        *y = aux1;
        x++;
        y--;
	}
    write (1,"2 while",7);
    i=0;
    while ( i < 4)
    {
        aux = tab[i] + '0';
        write(1,&aux,1);
        i++;
    }
    
}

int main (void)
{
    int str[4];

    str[0] = 1;
    str[1] = 2;
    str[2] = 3;
    str[3] = 4;
    ft_rev_int_tab(str, 4);
}

