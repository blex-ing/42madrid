/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42madrid>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/08 16:16:30 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/08 20:18:33 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putstr(int *str)
{
	int		i;
	char	aux;

	i = 0;
	if (str == NULL)
	{
		return ;
	}
	else
	{
		while (str[i] != '\0')
		{
			aux = str[i] + '0';
			write(1, &aux, 1);
			i++;
		}
	}
}

void	ft_swap(int *a, int *b)
{
	int	temp;

	temp = *a;
	*a = *b;
	*b = temp;
}
void	ft_rev_int_tab(int *tab, int size)
{
	int	first;
	int	second;
	int	aux;

	first = 0;
	second = size -1;
	while (first < size / 2)
	{
		aux = tab[first];
		/*tab[first] = tab[second - first];
		tab[second - first] = aux;*/
		ft_swap(&tab[first], &tab[second - first]);
		first++;
	}
}

/*
int main (void)
{
    int str[4];

    str[0] = 1;
    str[1] = 2;
    str[2] = 3;
    str[3] = 4;
    ft_rev_int_tab(str, 4);

	ft_putstr(str);
}*/