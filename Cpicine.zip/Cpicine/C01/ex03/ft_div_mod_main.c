/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42madrid>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/07 17:10:53 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/08 17:51:58 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

void	ft_div_mod(int a, int b, int *div, int *mod)
{
	*div = a / b;
	*mod = a % b;
}

int	main(void)
{
	int	num1;
	int	num2;
	int	division;
	int	modulo;

	num1 = 25;
	num2 = 10;

	division = 0;
	modulo = 0;

	ft_div_mod(num1, num2, &division, &modulo);

	printf("\n num1 %d y num2 %d \n div=%d \t mod =%d",num1,num2,division,modulo);
}
