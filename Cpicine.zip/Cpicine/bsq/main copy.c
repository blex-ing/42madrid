/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/19 19:37:04 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/21 18:29:01 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "library.h"
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

void	ft_search_number(char *dict, char *num_zeros)
{
	char	*word;
	int		cont;

	word = ft_strstr(dict, num_zeros);
	cont = 0;
	if (word != NULL)
	{
		while (word[cont] != '\n')
		{
			if (word[cont] >= 'a' && word[cont] <= 'z')
			{
				ft_putchar(word[cont]);
			}
			cont++;
		}
	}
	ft_print_line(" ");
}

void squared(char *map, char size, char vacum, char block)
{
	// int k;
	// int c;
	// int f;
	
	ft_print_line(map);
	ft_print_line(&size);
	ft_print_line(&vacum);
	ft_print_line(&block);
	// c = i + (size + 1)* j;
	// f = (size + 1)*i + j;
	// pos = c + f;

	// k = 2;
	// while ()
	// {
	// 	if (map[] == vacum && no estamos en el final)
	// 		k++;
	// 	else if (//posicion == vacio && no estamos en el final)


	// }


}



int	ft_process_doc(char *url)
{
	int		size_dict;
	int		archivo;
	int		bytes_leidos;
	char	*contenido;

	size_dict = ft_size_dictionary(url);
	archivo = open(url, O_RDONLY);
	if (archivo == -1)
	{
		ft_print_line("Could not open the file.\n");
		return (1);
	}
	if (size_dict < 1)
	{
		ft_print_line("Empty file.\n");
		return (1);
	}
	contenido = (char *)malloc(size_dict + 1);
	if (contenido == NULL)
	{
		ft_print_line("Error allocating memory.\n");
		close(archivo);
		return (1);
	}
	bytes_leidos = read(archivo, contenido, size_dict);
	contenido[bytes_leidos] = '\0';
	ft_print_line(url);
	ft_print_line("\n");
	ft_print_line(contenido);
	close(archivo);
	free(contenido);
	return (0);
}

void	ft_control_map(char *map)
{
	if (*map)
	{
		ft_process_doc(map);
	}
	else
	{
		ft_print_line("ERROR TYPE MAP");
	}
}

int	main(int argc, char *argv[])
{
	if (argc == 2)
	{
		ft_control_map(argv[1]);
	}
	else if (argc >= 3)
	{
		ft_print_line("Execution of more maps");
	}
	else
	{
		ft_print_line("Give me a map");
	}
	return (0);
}
