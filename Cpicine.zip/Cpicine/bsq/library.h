/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   library.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/19 19:36:24 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/21 15:11:57 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef LIBRARY_H
# define LIBRARY_H

int		ft_str_is_letter(char *str);
void	ft_putchar(char c);
int		ft_size_dictionary(char *url);
void	ft_print_line(char *str);
int		size_num(char *num);
char	*ft_strstr(char *str, char *to_find);

#endif
