/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/19 19:37:04 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/21 18:45:33 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "library.h"
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

void	squared(char *map, char size, char vacum, char block)
{
	ft_print_line(map);
	ft_print_line("\n");
	ft_putchar(size);
	ft_putchar(vacum);
	ft_putchar(block);
}

int	ft_process_doc(char *url)
{
	int		size_dict;
	int		archivo;
	int		bytes_leidos;
	char	*contenido;

	size_dict = ft_size_dictionary(url);
	archivo = open(url, O_RDONLY);
	if ((archivo == -1) || (size_dict < 1))
	{
		ft_print_line("Could not open the file.\nor \n Empty file.\n");
		return (1);
	}
	contenido = (char *)malloc(size_dict + 1);
	if (contenido == NULL)
	{
		ft_print_line("Error allocating memory.\n");
		close(archivo);
		return (1);
	}
	bytes_leidos = read(archivo, contenido, size_dict);
	contenido[bytes_leidos] = '\0';
	squared(contenido, '9', '.', 'o');
	close(archivo);
	free(contenido);
	return (0);
}

void	ft_control_map(char *map)
{
	if (*map)
	{
		ft_process_doc(map);
	}
	else
	{
		ft_print_line("ERROR TYPE MAP");
	}
}

int	main(int argc, char *argv[])
{
	if (argc == 2)
	{
		ft_control_map(argv[1]);
	}
	else if (argc >= 3)
	{
		ft_print_line("Execution of more maps");
	}
	else
	{
		ft_print_line("Give me a map");
	}
	return (0);
}
