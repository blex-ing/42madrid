/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr_non_printable.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42madrid>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/13 17:32:43 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/14 21:52:11 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	ft_putchar(char a)
{
	write(1, &a, 1);
}

int	ft_str_is_printable(char *str)
{
	while (*str != '\0')
	{
		if ((*str > ' ') && (*str <= '~'))
		{
			return (1);
		}
		str++;
	}
	return (0);
}

int	ft_strlen(char *str)
{
	int	len;

	len = 0;
	while (*str != '\0')
	{
		len++;
		str++;
	}
	return (len);
}

void	ft_putstr_non_printable(char *str)
{
	char	temp[1];
	int		len;

	len = ft_strlen(str);
	while (len != 0)
	{
		temp[0] = *str;
		if (!ft_str_is_printable(temp))
		{
			write(1, "\\", 1);
			ft_putchar("0123456789abcdef"[*str / 16]);
			ft_putchar("0123456789abcdef"[*str % 16]);
		}
		else
		{	
			ft_putchar(*str);
		}
		str++;
		len--;
	}
}
