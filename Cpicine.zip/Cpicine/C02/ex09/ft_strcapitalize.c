/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42madrid>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/12 19:28:14 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/14 21:46:03 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_lowercase(char str)
{
	if ((str < 'a') || (str > 'z'))
	{
		return (0);
	}
	return (1);
}

int	ft_str_is_uppercase(char str)
{
	if ((str < 'A') || (str > 'Z'))
	{
		return (0);
	}
	return (1);
}

int	ft_str_is_break_simbol(char str)
{
	if ((str == ' ') || (str == '+') || (str == '-'))
	{
		return (1);
	}
	return (0);
}

int	ft_str_is_alpha(char str)
{
	if (((str >= 'a') && (str <= 'z')) || ((str >= 'A') && (str <= 'Z'))
		|| ((str >= '0') && (str <= '9')))
	{
		return (0);
	}
	return (1);
}

char	*ft_strcapitalize(char *str)
{
	int		cont;
	int		switch_capi;
	char	*aux;

	aux = str;
	cont = 0;
	switch_capi = 1;
	while (*aux != '\0')
	{
		if (ft_str_is_lowercase(aux[cont]) && switch_capi == 1)
		{
			aux[cont] = *aux - 32;
			switch_capi = 0;
		}
		else if (ft_str_is_uppercase(aux[cont]) && switch_capi == 0)
		{
			aux[cont] = *aux + 32;
			switch_capi = 0;
		}
		else
		switch_capi = ft_str_is_alpha(aux[cont]);
		aux++;
	}
	return (str);
}
