/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strupcase.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42madrid>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/12 17:14:08 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/14 20:22:27 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_alpha(char str)
{
	if (((str < 'a') || (str > 'z')) && ((str < 'A') || (str > 'Z')))
	{
		return (0);
	}
	return (1);
}

int	ft_str_is_lowercase(char str)
{
	if ((str < 'a') || (str > 'z'))
	{
		return (0);
	}
	return (1);
}

char	*ft_strupcase(char *str)
{
	int	cont;

	cont = 0;
	while (str[cont] != '\0')
	{
		if (ft_str_is_alpha(str[cont]))
		{
			if (ft_str_is_lowercase(str[cont]))
			{
				str[cont] = str[cont] - 32;
			}
		}
		cont++;
	}
	str[cont] = '\0';
	return (str);
}
