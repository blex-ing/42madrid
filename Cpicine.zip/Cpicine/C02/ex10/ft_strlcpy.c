/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42madrid>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/13 13:32:59 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/15 16:07:21 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	len_str(char *str)
{
	int	len;

	len = 0;
	while (str[len] != '\0')
	{
		len ++;
	}
	return (len);
}

unsigned int	ft_strlcpy(char *dest, char *src, unsigned int size)
{
	unsigned int	len_dest;
	unsigned int	len_src;

	len_src = len_str(src);
	len_dest = 0;
	if (size != 0)
	{
		while (*src != '\0' && len_dest < (size -1))
		{
			dest[len_dest] = *src;
			src++;
			len_dest++;
		}
		dest[len_dest] = '\0';
	}
	return (len_src);
}
