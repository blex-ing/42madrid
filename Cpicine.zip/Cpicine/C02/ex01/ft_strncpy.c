/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42madrid>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/12 14:55:37 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/12 16:10:10 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	int	cont;

	cont = 0;
	while ((src[cont] != '\0') && (n > 0))
	{
		dest[cont] = src[cont];
		cont++;
		n--;
	}
	while (n > 0)
	{
		dest[cont] = '\0';
		cont++;
		n--;
	}
	return (dest);
}
