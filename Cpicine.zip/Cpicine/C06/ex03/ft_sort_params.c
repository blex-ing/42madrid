/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_params.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/21 20:16:39 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/22 02:52:24 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_line(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		write(1, &str[i], 1);
		i++;
	}
}

void	ft_swap(char **a, char **b)
{
	char	*aux;

	aux = *a;
	*a = *b;
	*b = aux;
}

int	ft_strcmp(char *s1, char *s2)
{
	unsigned char	s11;
	unsigned char	s22;

	while (*s1 && (*s1 == *s2))
	{
		s1++;
		s2++;
	}
	s11 = *(unsigned char *)s1;
	s22 = *(unsigned char *)s2;
	return (s11 - s22);
}

void	ft_sort_in_tab(char **tab, int size)
{
	int		i;	
	int		j;
	int		cont;

	i = 1;
	j = size - 1;
	cont = 1;
	while (cont < j)
	{
		while (i < j)
		{
			if (ft_strcmp(tab[i], tab[i +1]) > 0)
			{
				ft_swap(&tab[i], &tab[i +1]);
			}
			i++;
		}
		cont++;
		i = 0;
	}
}

int	main(int argc, char *argv[])
{
	int	i;

	i = 1;
	if (argc > 0)
	{
		ft_sort_in_tab(argv, argc);
		while (i < argc)
		{
			ft_print_line(argv[i]);
			ft_print_line("\n");
			i++;
		}
	}
	return (0);
}
