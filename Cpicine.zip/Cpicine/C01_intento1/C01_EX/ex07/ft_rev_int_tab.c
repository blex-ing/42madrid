/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/08 16:16:30 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/22 18:16:00 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putstr(int *str)
{
	int		i;
	char	aux;

	i = 0;
	if (str != NULL)
	{
		while (*str != '\0')
		{
			aux = *str + '0';
			write(1, &aux, 1);
			i++;
			str++;
		}
	}
}

void	ft_rev_int_tab(int *tab, int size)
{
	int	first;
	int	last;
	int	aux;

	first = 0;
	last = size -1;
	while (first < size / 2)
	{
		aux = tab[first];
		tab[first] = tab[last - first];
		tab[last - first] = aux;
		first++;
	}
	tab[size] = '\0';
	ft_putstr(tab);
}

int main(void)
{
	int list[] = {1,2,3,4,5,6};
	ft_rev_int_tab(list, 6);
	return (0);
}