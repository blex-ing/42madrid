/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/05 22:51:11 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/22 16:41:46 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char f1, char f2)
{
	write(1, &f1, 1);
	write(1, &f2, 1);
}

void	ft_numbers_to_char(int first)
{
	char	f1;
	char	f2;

	f2 = first % 10 + '0';
	f1 = first / 10 + '0';
	ft_putchar(f1, f2);
}

void	ft_print_comb2(void)
{
	int	first;
	int	second;

	first = 0;
	while (first <= 98)
	{
		second = first + 1;
		while (second <= 99)
		{
			ft_numbers_to_char(first);
			write(1, " ", 1);
			ft_numbers_to_char(second);
			if (first != 98)
			{
				write(1, ", ", 2);
			}
			second++;
		}
		first++;
	}
}
