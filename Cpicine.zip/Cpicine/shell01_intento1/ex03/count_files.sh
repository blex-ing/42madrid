#! /bin/bash
find . | grep -c ""
