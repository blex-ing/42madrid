/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/19 17:30:17 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/21 20:11:24 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_isspace(char space)
{
	if (((space >= 9) && (space <= 13)) || (space == 32))
	{
		return (1);
	}
	return (0);
}

int	ft_isoperator(char operator)
{
	if (operator == '-' || operator == '+')
		return (1);
	return (0);
}

int	ft_isnum(char num)
{
	if (num >= '0' && num <= '9')
		return (1);
	return (0);
}

int	ft_atoi(char *str)
{
	char	*mov;
	int		operator;
	int		num;

	mov = str;
	operator = 1;
	num = 0;
	while (ft_isspace(*mov))
	{
		mov++;
	}
	while (ft_isoperator(*mov))
	{
		if (*mov == '-')
			operator *= -1;
		mov++;
	}
	while (ft_isnum(*mov) && (*mov != '\0'))
	{
		num = (num * 10) + (*mov - '0');
		mov++;
	}
	return (operator * num);
}
