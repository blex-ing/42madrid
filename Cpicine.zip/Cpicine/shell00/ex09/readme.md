# Comando para probar el funcionamiento.
file -m ft_magic.magic test.txt

## Parte	Descripción
* 41	Una cadena de texto o una secuencia de bytes que se busca en el archivo.
* string	Indica que se está buscando una coincidencia exacta de la secuencia de bytes.
* 42	La secuencia de bytes específica que se busca en el archivo.
* 42 file	La descripción o el nombre del tipo de archivo que se asignará si se encuentra una coincidencia exitosa.

Ahora, una breve explicación sobre los archivos magic y la línea de comando "41 string 42 42 file":

Archivo Magic:

Un archivo magic es un archivo de configuración utilizado por la herramienta file en sistemas Unix y Linux para identificar el tipo de contenido de un archivo.
Contiene reglas y patrones que definen cómo reconocer diferentes tipos de archivos basados en secuencias de bytes específicas o características estructurales.
Las reglas en un archivo magic se aplican en secuencia hasta que se encuentra una coincidencia exitosa para determinar el tipo de archivo.
Línea de Comando "41 string 42 42 file":

Esta línea de comando se usa en un archivo magic para definir una regla de identificación de tipo de archivo.
La secuencia de bytes "41" se busca en el archivo utilizando la instrucción "string" para una coincidencia exacta.
Si se encuentra la secuencia de bytes "42" después de la coincidencia exitosa de "41", el archivo se clasificará como un "42 file".
En resumen, la línea de comando "41 string 42 42 file" en un archivo magic busca la secuencia de bytes "41" en el archivo y, si se encuentra, busca la secuencia de bytes "42" después de la coincidencia de "41". Si ambas secuencias se encuentran correctamente, el archivo se clasificará como un "42 file".






