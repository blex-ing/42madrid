#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define SIZE 6

void printBoard(int *board);
int solveSkyscrapers(int *board);
int checkVisibility(int *board, int row, int col);
int isSafe(int *board, int row, int col, int num);
int solveUtil(int *board, int row, int col);

void printBoard(int *board) {
    int i = 0;
    int j;
    char buffer[3];

    while (i < SIZE) {
        j = 0;
        while (j < SIZE) {
            sprintf(buffer, "%d ", *(board + (i * SIZE) + j));
            write(STDOUT_FILENO, buffer, 2);
            j++;
        }
        write(STDOUT_FILENO, "\n", 1);
        i++;
    }
}

int solveSkyscrapers(int *board) {
    return solveUtil(board, 0, 0);
}

int checkVisibility(int *board, int row, int col) {
    int count = 1;
    int max_height = *(board + (row * SIZE) + col);
    int i = row + 1;

    while (i < SIZE) {
        if (*(board + (i * SIZE) + col) > max_height) {
            max_height = *(board + (i * SIZE) + col);
            count++;
        }
        i++;
    }
    return count;
}

int isSafe(int *board, int row, int col, int num) {
    int i = 0;

    // Check if the number already exists in the same column
    while (i < SIZE) {
        if (*(board + (i * SIZE) + col) == num) {
            return 0;
        }
        i++;
    }

    // Check if the number already exists in the same row
    i = 0;
    while (i < SIZE) {
        if (*(board + (row * SIZE) + i) == num) {
            return 0;
        }
        i++;
    }

    return 1;
}

int solveUtil(int *board, int row, int col) {
    if (row == SIZE) {
        // We have reached the end of the board
        return 1;
    }

    int nextRow, nextCol;

    if (col == SIZE - 1) {
        // Move to the next row
        nextRow = row + 1;
        nextCol = 0;
    } else {
        // Move to the next column
        nextRow = row;
        nextCol = col + 1;
    }

    if (*(board + (row * SIZE) + col) != 0) {
        // The cell is already filled, skip to the next cell
        return solveUtil(board, nextRow, nextCol);
    }

    int num = 1;
    while (num <= SIZE) {
        if (isSafe(board, row, col, num)) {
            // Try placing the number in the cell
            *(board + (row * SIZE) + col) = num;

            // Check if it satisfies the visibility condition
            if (checkVisibility(board, row, col) == *(board + (row * SIZE) + SIZE + col)) {
                if (solveUtil(board, nextRow, nextCol)) {
                    return 1;
                }
            }

            // Undo the placement and try the next number
            *(board + (row * SIZE) + col) = 0;
        }
        num++;
    }

    return 0;
}

void ft_print_argv(char *argv)
{
    int cont;
    char    temp;

    cont = 0;
    while (argv[cont] != '\0')
    {
        temp = argv[cont];
        write(1,&temp,1);
        cont++;
    }
}

void ft_print_argv(char *argv)
{
    int cont;
    char    temp;

    cont = 0;
    while (argv[cont] != '\0')
    {
        temp = argv[cont];
        write(1,&temp,1);
        cont++;
    }
}

int main(int argc , char *argv[2]) {
    int *board = (int *)malloc(SIZE * SIZE * sizeof(int));

    if (board == NULL) {
        write(STDOUT_FILENO, "Memory allocation failed.\n", 26);
        return 1;
    }

    // Initialize the board with zeroes
    int i = 0;
    while (i < SIZE * SIZE) {
        *(board + i) = 0;
        i++;
    }
    int temp;
    temp = 0;
    ft_print_argv(argv[1]);
    //write(1, argv[1],4);
    write(1, "\n",1);
   

    // Set visibility conditions on the borders
    *(board + 1) = 2; //columnas superior
    *(board + 2) = 3; 
    *(board + 3) = 3; 
    *(board + 4) = 1; 

    *(board + 6) = 2; 
    *(board + 12) = 1; 
    *(board + 18) = 2; 
    *(board + 24) = 3; 

    *(board + 11) = 2; 
    *(board + 17) = 1; 
    *(board + 23) = 2; 
    *(board + 29) = 3;

    *(board + 31) = 3; //columnas inferior
    *(board + 32) = 2; 
    *(board + 33) = 1; 
    *(board + 34) = 3;  
    printBoard(board);
    if (solveSkyscrapers(board)) {
        write(STDOUT_FILENO, "Solution:\n", 10);
        printBoard(board);
    } else {
        write(STDOUT_FILENO, "No solution found.\n", 19);
    }

    free(board);

    return 0;
}
