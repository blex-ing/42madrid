/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush_main.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42madrid>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/10 18:33:35 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/10 20:11:23 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int	main()
{
	int	size;
	int	**board;
	int	i;
	int	j;

	write(1,"____",4);
	size = 6;// Tamaño del tablero
	board = (int **)malloc(size * sizeof(int *));// Reserva de memoria para las filas
	i = 0;

	while (i < size)
	{
		board[i] = (int *)malloc(size * sizeof(int));// Reserva de memoria para las columnas
		int	j;
		j = 0;

		while (j < size)
		{
			board[i][j] = 0;// Inicialización de los elementos del tablero a 0
			j++;
		}
		i++;
	}

    //Imprimir el contenido del tablero
    i = 0;
	write(1,"____",4);
    while (i < size) 
    {
		int j = 0;
		while (j < size) 
        {
			printf("%d ", board[i][j]);
			j++;
		}
		printf("\n");
		i++;
    }

    // Liberar la memoria asignada
    i = 0;
	while (i < size)
	{
		free(board[i]);
		i++;
	}
	free(board);

	return (0);
}
