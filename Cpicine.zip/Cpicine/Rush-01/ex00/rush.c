/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sgil-moy <sgil-moy@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/10 11:26:52 by sgil-moy          #+#    #+#             */
/*   Updated: 2023/06/10 17:33:10 by sgil-moy         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void print_map(int map[][4])
{
    char c;
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            c = map[i][j] + '0';
            write(1,&c,1);
        }
        write(1,"\n",2);
    }
}

//--------------------------------

void set_row(int (*map)[4], int row, int new_row[])
{
    for(int i = 0; i < 4; ++i)
    {
        map[row][i] = new_row[i];
    }
}

//--------------------------------

int check_col(int map[][4], int col, int order, int compare[][4], int size)
{
    int result = 1;//en principio mal
    int colval = col;

    if(order > 0)//en funcion del orden
    {
        for(int caso = 0; caso < size; ++caso)//por cada caso
        {
            for(int index = 0; index < 4; ++index)//por cada indice
            {
                if  (map[index][col] == compare[caso][index])  result = 0;
                else                                            result = 1;
            }
            if(result==0) return (0); //Si hay un cas0 entero bien se pasa la prueba
        }
    }
    else
    {
        for(int caso = 0; caso < size; ++caso)//por cada caso
        {
            for(int index = 0; index < 4; ++index)//por cada indice
            {
                if  (map[index][col] == compare[caso][3-index])    result = 0;
                else                                                result = 1;
            }
            if(result==0) return (0); //Si hay un cas0 entero bien se pasa la prueba
        }
    }
    
    return(1); //si no es igual que ninguno falla
}

int check_row(int map[][4], int row, int order, int compare[][4], int size)
{
    int result = 1;//en principio mal
    int rowval = row;
    if(order > 0)//en funcion del orden
    {
        for(int caso = 0; caso < size; ++caso)//por cada caso
        {
            for(int index = 0; index < 4; ++index)//por cada indice
            {
                if  (map[row][index] == compare[caso][index])  result = 0;
                else                                            result = 1;
            }
            if(result==0) return (0); //Si hay un cas0 entero bien se pasa la prueba
        }
    }
    else
    {
        for(int caso = 0; caso < size; ++caso)//por cada caso
        {
            for(int index = 0; index < 4; ++index)//por cada indice
            {
                if  (map[row][index] == compare[caso][3-index])    result = 0;
                else                                                result = 1;
            }
            if(result==0) return (0); //Si hay un cas0 entero bien se pasa la prueba
        }
    }
    
    return(1); //si no es igual que ninguno falla
}
//

int check_map(int map[][4], int val[16])    //recibe el array del mapa y el array con los valores de cada fila/columna
{
    //COMBINACIONES POSIBLES EN FUNCION DEL VALOR
    //VAL == 1
    int r1[6][4] = { {4,1,2,3},
                     {4,1,3,2},
                     {4,2,1,3},
                     {4,2,3,1},
                     {4,3,1,2},
                     {4,3,2,1}};
    //VAL == 2                     
    int r2[11][4] = {{1,4,2,3},
                     {1,4,3,2},
                     {2,1,4,3},
                     {2,4,1,3},
                     {2,4,3,1},
                     {3,1,2,4},
                     {3,1,4,2},
                     {3,2,1,4},
                     {3,2,4,1},
                     {3,4,1,2},
                     {3,4,2,1}};
    //VAL == 3
    int r3[6][4] = {{1,2,4,3},
                    {1,3,2,4},
                    {1,3,4,2},
                    {2,1,3,4},
                    {2,3,1,4},
                    {2,3,4,1}};
    //VAL == 4
    int r4[1][4] = { {1,2,3,4}};
    
    /*
    pasar por cada fila/columna en cada direccion comparando los valores con los posibles
    todo tiene que coincidir
    */
    
    int i = 0;
    while(i < 16)//en cada caso
    {
        if(i < 4)       //top
        {
            if      (val[i] == 1)   if (check_col(map, i, 1, r1,  6) == 1)  return (1);
            else if (val[i] == 2)   if (check_col(map, i, 1, r2, 11) == 1)  return (1);
            else if (val[i] == 3)   if (check_col(map, i, 1, r3,  6) == 1)  return (1);
            else                    if (check_col(map, i, 1, r4,  1) == 1)  return (1);
        }
        else if (i<8)   //bot
        {
            if      (val[i] == 1)   if (check_col(map, i-4, -1, r1,  6) == 1) return (1);
            else if (val[i] == 2)   if (check_col(map, i-4, -1, r2, 11) == 1) return (1);
            else if (val[i] == 3)   if (check_col(map, i-4, -1, r3,  6) == 1) return (1);
            else                    if (check_col(map, i-4, -1, r4,  1) == 1) return (1);
        }
        else if (i<12)  //left
        {
            if      (val[i] == 1)   if (check_row(map, i-8, 1, r1,  6) == 1)  return (1);
            else if (val[i] == 2)   if (check_row(map, i-8, 1, r2, 11) == 1)  return (1);
            else if (val[i] == 3)   if (check_row(map, i-8, 1, r3,  6) == 1)  return (1);
            else                    if (check_row(map, i-8, 1, r4,  1) == 1)  return (1);
        }
        else            //right
        {
            if      (val[i] == 1)   if (check_row(map, i-12, -1, r1,  6) == 1) return (1);
            else if (val[i] == 2)   if (check_row(map, i-12, -1, r2, 11) == 1) return (1);
            else if (val[i] == 3)   if (check_row(map, i-12, -1, r3,  6) == 1) return (1);
            else                    if (check_row(map, i-12, -1, r4,  1) == 1) return (1);
        }
        ++i;
    }
    return (0);   //BIEN
}

//--------------------------------
void update(int map[][4], int vals[16])
{
    //COMBINACIONES POSIBLES EN FUNCION DEL VALOR
    //VAL == 1
    int r1[6][4] = { {4,1,2,3},
                     {4,1,3,2},
                     {4,2,1,3},
                     {4,2,3,1},
                     {4,3,1,2},
                     {4,3,2,1}};
    //VAL == 2                     
    int r2[11][4] = {{1,4,2,3},
                     {1,4,3,2},
                     {2,1,4,3},
                     {2,4,1,3},
                     {2,4,3,1},
                     {3,1,2,4},
                     {3,1,4,2},
                     {3,2,1,4},
                     {3,2,4,1},
                     {3,4,1,2},
                     {3,4,2,1}};
    //VAL == 3
    int r3[6][4] = {{1,2,4,3},
                    {1,3,2,4},
                    {1,3,4,2},
                    {2,1,3,4},
                    {2,3,1,4},
                    {2,3,4,1}};
    //VAL == 4
    int r4[1][4] = { {1,2,3,4}};
    
    
    int row_index[4];   //indice por el que se va probando
    int row_vals [4];   //valor de la fila (1-4)
    int row_max. [4];   //cantidad maxima de pruebas que hay con su valor
    
    for(int i=0;i<4;++i)
    {
        row_index[i]=0;
        row_vals[i]=vals[8+i];
        
        if      (row_vals[i]==1)    row_max[i] =  6;
        else if (row_vals[i]==2)    row_max[i] = 11;
        else if (row_vals[i]==3)    row_max[i] =  6;
        else                        row_max[i] =  1;
    }
    
    //bucle en el que va haciendo las pruebas con todas las filas del tablero intentando conseguir que encaje 
    //tanto filas como columnas, si lo consigue termina
    //!!!!!!!!!!!!!!!
    while(a < 4)
    {
        //CAMBIAR EL VALOR DE LA FILA 0        set_row(int (*map)[4], 0, int new_row[]);
        
        while(b<4)
        {
                    //CAMBIAR EL VALOR DE LA FILA 1

            while(c<4)
            {
                    //CAMBIAR EL VALOR DE LA FILA 2

                while(d<4)
                {
                    //CAMBIAR EL VALOR DE LA FILA 3
                    if(check_map(map, vals)==0) c = 4;//si esta bien se sale
                    ++c;
                }
                if(check_map(map, vals)==0) c = 4;//si esta bien se sale
                //RESETEA indice DE 3
                ++c;
            }
        
            if(check_map(map, vals)==0) b = 4;//si esta bien se sale
            //RESETEA indice DE 2 Y 3
            ++b;
        }
        if(check_map(map, vals)==0) a = 4;//si esta bien se sale
        //RESETEA indice DE 1, 2 y 3
        ++a;
    }
}
//--------------------------------

int main()
{
    int vals[16] = {4, 3, 2, 1, 1, 2, 2, 2, 4, 3, 2, 1, 1, 2, 2, 2};

    int map[4][4] = { {0, 0, 0, 0},
                      {0, 0, 0, 0},
                      {0, 0, 0, 0},
                      {0, 0, 0, 0}};

    int solved_map[4][4] = {{1, 2, 3, 4}, {2, 3, 4, 1}, {3, 4, 1, 2}, {4, 1, 2, 3}};
    
    update(map, vals);
    print_map(map);
    
    return (0);
}
