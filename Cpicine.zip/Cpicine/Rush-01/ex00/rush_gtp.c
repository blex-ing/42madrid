#include <stdio.h>
#include <unistd.h>

#define SIZE 4

void    printBoard(int board[][SIZE]);
int solveSkyscrapers(int board[][SIZE]);
int checkVisibility(int board[][SIZE], int row, int col);
int isSafe(int board[][SIZE], int row, int col, int num);
int solveUtil(int board[][SIZE], int row, int col);

void printBoard(int board[][SIZE]) {
    int i = 0, j = 0;
    char buffer[3];
    
    while (i < SIZE) {
        j = 0;
        while (j < SIZE) {
            sprintf(buffer, "%d ", board[i][j]);
            write(STDOUT_FILENO, buffer, 2);
            j++;
        }
        write(STDOUT_FILENO, "\n", 1);
        i++;
    }
}

int solveSkyscrapers(int board[][SIZE]) {
    printBoard(board);

    return solveUtil(board, 0, 0);
}

int checkVisibility(int board[][SIZE], int row, int col) {
    int count = 1;
    int max_height = board[row][col];
    int i = row + 1;

    while (i < SIZE) {
        if (board[i][col] > max_height) {
            max_height = board[i][col];
            count++;
        }
        i++;
    }
    
    return count;
}

int isSafe(int board[][SIZE], int row, int col, int num) {
    int i = 0;

    while (i < SIZE) {
        if (board[i][col] == num) {
            return 0;
        }
        i++;
    }
    
    i = 0;
    
    while (i < SIZE) {
        if (board[row][i] == num) {
            return 0;
        }
        i++;
    }
    
    return 1;
}

int solveUtil(int board[][SIZE], int row, int col) {
    if (row == SIZE) {
        return 1;
    }

    int nextRow, nextCol;

    if (col == SIZE - 1) {
        nextRow = row + 1;
        nextCol = 0;
    } else {
        nextRow = row;
        nextCol = col + 1;
    }

    if (board[row][col] != 0) {
        return solveUtil(board, nextRow, nextCol);
    }

    int num = 1;
    //var temporal
    char temp;
    while (num <= SIZE) {
        if (isSafe(board, row, col, num)) {
            board[row][col] = num;
            temp = num + '0';
            write(1, &temp,1);
            write(1, "\n",1);
            printBoard(board);

            if (checkVisibility(board, row, col) == board[row][SIZE + col]) {
                if (solveUtil(board, nextRow, nextCol)) {
                    return 1;
                }
            }

            board[row][col] = 0;
        }
        num++;
    }

    return 0;
}

int main() {
    int board[SIZE][SIZE] = { {4, 0, 1, 0},
                              {0, 4, 0, 0},
                              {1, 0, 4, 0},
                              {0, 0, 0, 4} };
    printBoard(board);

    if (solveSkyscrapers(board)) {
        write(STDOUT_FILENO, "Solution:\n", 10);
        printBoard(board);
    } else {
        write(STDOUT_FILENO, "No solution found.\n", 19);
    }

    return 0;
}
