#! /bin/bash
#find . -type f | wc -l
find . | grep -c