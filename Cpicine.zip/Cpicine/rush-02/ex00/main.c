/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/17 17:40:08 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/18 17:59:46 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "librery.h"
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

void	ft_search_number(char *dict, char *num_zeros)
{
	char	*word;
	int		cont;

	word = ft_strstr(dict, num_zeros);
	cont = 0;
	if (word != NULL)
	{
		while (word[cont] != '\n')
		{
			if (word[cont] >= 'a' && word[cont] <= 'z')
			{
				ft_putchar(word[cont]);
			}
			cont++;
		}
	}
	ft_print_line(" ");
}

void	ft_translate_number(char *dict, char *num)
{
	int		i;
	int		j;
	char	num_zeros[10];

	i = 0;
	while (num[i] != '\0')
		i++;
	i--;
	if ((i == 1) && (num[i - 1] == '1'))
		ft_search_number(dict, num);
	else
	{
		while (i >= 0)
		{
			j = 0;
			num_zeros[0] = '\0';
			num_zeros[j] = *num;
			j++;
			while (j <= i)
			{
				num_zeros[j] = '0';
				j++;
			}
			num_zeros[j] = '\0';
			ft_search_number(dict, num_zeros);
			num++;
			i--;
		}
	}
	ft_print_line("\n");
}

int	ft_process_doc(char *num, char *url)
{
	int		size_dict;
	int		archivo;
	int		bytes_leidos;
	char	*contenido;

	size_dict = ft_size_dictionary(url);
	archivo = open(url, O_RDONLY);
	if (archivo == -1)
	{
		ft_print_line("Could not open the file.\n");
		return (1);
	}
	contenido = (char *)malloc(size_dict + 1);
	if (contenido == NULL)
	{
		ft_print_line("Error allocating memory.\n");
		close(archivo);
		return (1);
	}
	bytes_leidos = read(archivo, contenido, size_dict);
	contenido[bytes_leidos] = '\0';
	ft_translate_number(contenido, num);
	close(archivo);
	free(contenido);
	return (0);
}

void	ft_control_number(char *num)
{
	if (ft_str_is_digit(num) == 1)
	{
		ft_process_doc(num, "./numbers.dict");
	}
	else
	{
		ft_print_line("ERROR TYPE NUM");
	}
}

int	main(int argc, char *argv[])
{
	if (argc == 2)
	{
		ft_control_number(argv[1]);
	}
	else if (argc == 3)
	{
		ft_print_line("Execution 2");
	}
	else
	{
		ft_print_line("I need 1 or 2 arg");
	}
	return (0);
}
