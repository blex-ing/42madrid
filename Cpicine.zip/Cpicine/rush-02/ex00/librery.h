/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   librery.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42madrid>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/18 15:04:55 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/18 16:04:47 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef LIBRERY_H
# define LIBRERY_H
# include "librery.c"

int		ft_str_is_digit(char *str);
void	ft_putchar(char c);
int		ft_size_dictionary(char *url);
void	ft_print_line(char *str);
int		size_num(char *num);
char	*ft_strstr(char *str, char *to_find);

#endif
