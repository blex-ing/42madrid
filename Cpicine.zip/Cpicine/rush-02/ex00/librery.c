/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   librery.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: frlorenz <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/17 17:40:09 by frlorenz          #+#    #+#             */
/*   Updated: 2023/06/18 15:04:21 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "librery.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

int	ft_str_is_digit(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] < 48 || str[i] > 57)
		{
			return (0);
		}
		i++;
	}
	return (1);
}

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

int	ft_size_dictionary(char *url)
{
	int		fd;
	char	buffer;
	int		size_dict;

	size_dict = 0;
	fd = open(url, O_RDONLY);
	while ((read(fd, &buffer, 1)) > 0)
	{
		size_dict++;
	}
	close(fd);
	return (size_dict);
}

void	ft_print_line(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		ft_putchar(str[i]);
		i++;
	}
}

char	*ft_strstr(char *str, char *to_find)
{
	char	*aux_str;
	char	*h_curr;
	char	*aux_to_find;
	int		match;

	aux_str = str;
	if (*to_find == '0')
		return (str);
	while (*aux_str)
	{
		h_curr = aux_str;
		aux_to_find = to_find;
		match = 1;
		while (*aux_to_find && match)
		{
			if (*h_curr != *aux_to_find)
				match = 0;
			h_curr++;
			aux_to_find++;
		}
		if (match)
			return (aux_str);
		aux_str++;
	}
	return (NULL);
}
