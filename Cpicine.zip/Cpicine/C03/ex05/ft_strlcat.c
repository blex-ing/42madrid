/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/15 19:37:36 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/19 16:02:30 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_strlen(char *str)
{
	int	cont;

	cont = 0;
	while (str[cont] != '\0')
	{
		cont++;
	}
	return (cont);
}

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	int	size_dest;
	int	size_src;
	int	total_size;
	int	cont;

	size_dest = ft_strlen(dest);
	size_src = ft_strlen(src);
	total_size = 0;
	if (size_dest > (int) size)
		total_size = size + size_src;
	else
		total_size = size_dest + size_src;
	cont = 0;
	while ((src[cont] != '\0') && (size_dest < (int) size -1))
	{
		dest[size_dest] = src[cont];
		cont++;
		size_dest++;
	}
	dest[size_dest] = '\0';
	return (total_size);
}
