/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42madrid>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/13 19:16:16 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/14 12:55:19 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strcmp(char *s1, char *s2)
{
	unsigned char	s11;
	unsigned char	s22;

	while (*s1 && (*s1 == *s2))
	{
		s1++;
		s2++;
	}
	s11 = *(unsigned char *)s1;
	s22 = *(unsigned char *)s2;
	return (s11 - s22);
}
