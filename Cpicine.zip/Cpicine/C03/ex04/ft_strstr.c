/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/14 13:11:00 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/19 14:46:34 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strstr(char *str, char *to_find)
{
	int	cont;
	int	cont2;

	cont = 0;
	cont2 = 0;
	if (to_find[cont2] == '\0')
		return (str);
	while (str[cont] != '\0')
	{
		while (str[cont + cont2] == to_find[cont2] && str[cont + cont2] != '\0')
		{
			cont2++;
		}
		if (to_find[cont2] == '\0')
			return (str + cont);
		cont++;
		cont2 = 0;
	}
	return (0);
}
