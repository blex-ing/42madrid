char	 *ft_strstr(char *str, char *to_find)
{
	int	it1;
	int	it2;

	it1 = 0;
	it2 = 0;
	if (to_find[it2] == '\0')
		return (str);
	while (str[it1] != '\0')
	{
		while (str[it1 + it2] == to_find[it2] && str[it1 + it2] != '\0')
			it2++;
		if (to_find[it2] == '\0')
			return (str + it1);
		it1++;
		it2 = 0;
	}
	return (0);
}

char	*ft_strstr(char *str, char *to_find)
{
	char	*aux_str;
	char	*h_curr;
	char	*aux_to_find;
	int		match;

	aux_str = str;
	if (*to_find == '0')
		return (str);
	while (*aux_str)
	{
		h_curr = aux_str;
		aux_to_find = to_find;
		match = 1;
		while (*aux_to_find && match)
		{
			if (*h_curr != *aux_to_find)
				match = 0;
			h_curr++;
			aux_to_find++;
		}
		if (match)
			return (aux_str);
		aux_str++;
	}
	return (0);
}