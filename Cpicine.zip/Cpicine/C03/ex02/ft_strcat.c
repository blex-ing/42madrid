/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42madrid>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/13 22:19:39 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/14 13:06:47 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strlen(char *str)
{
	int	cont;

	cont = 0;
	while (*str != '\0')
	{
		str++;
		cont ++;
	}
	return (cont);
}

int	ft_strlen_p(char *str)
{
	char	*p;

	p = str;
	while (*p)
	{
		p++;
	}
	return (p - str);
}

char	*ft_strcat(char *dest, char *src)
{
	int	len_des;

	len_des = ft_strlen_p(dest);
	while (*src)
	{
		dest[len_des] = *src;
		src++;
		len_des++;
	}
	dest[len_des] = '\0';
	return (dest);
}
