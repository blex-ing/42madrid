/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <aleespin@student.42madrid>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/14 00:46:36 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/14 13:09:42 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_strlen_p(char *str)
{
	char	*p;

	p = str;
	while (*p)
	{
		p++;
	}
	return (p - str);
}

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	int	len_des;

	len_des = ft_strlen_p(dest);
	while (*src && (nb > 0))
	{
		dest[len_des] = *src;
		src++;
		len_des++;
		nb--;
	}
	dest[len_des] = '\0';
	return (dest);
}

// int main(void)
// {
// 	char	t1[10] = "hola";
// 	char	t2[5] = "soy";
// 	int 	cont;
// 	char	*p;

// 	cont = 0;
// 	p = ft_strncat(t1, t2, 3);
// 	while ( t1[cont]!= '\0')
// 	{
// 		write(1, &t1[cont], 1);
// 		cont++;
// 	}
// 	write(1, "\n", 1);
// 	char	aux;

// 	while (*p != '\0')
// 	{
// 		aux = *p;
// 		write(1, &aux, 1);
// 		p++;
// 	}
// 	return (0);
// }
