/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_alphabet.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/05 13:34:08 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/05 14:19:49 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_alphabet(void)
{
	static char	c = 'a';

	while (c != '{')
	{
		write(1, &c, 1);
		c++;
	}
}

int	main(int argc, char *argv[])
{
	ft_print_alphabet();
	return (0);
}
