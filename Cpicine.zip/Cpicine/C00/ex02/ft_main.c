/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_reverse_alphabet.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/05 14:22:09 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/05 14:52:59 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_reverse_alphabet(void)
{
	static char	c = 'z';

	while (c != '`')
	{
		write(1, &c, 1);
		c--;
	}
}

int	main(int argc, char *argv[])
{
	ft_print_reverse_alphabet();
	return (0);
}
