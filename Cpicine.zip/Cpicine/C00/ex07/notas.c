int	main(void)
{
	ft_putnbr(-234);
	return (0);
}

int	size_of(int num)
{
	int	size_num;

	size_num = 0;
	while (num != 0)
	{
		num = num / 10;
		size_num++;
	}
	return (size_num);
}

