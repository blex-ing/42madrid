/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aleespin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/06 14:27:34 by aleespin          #+#    #+#             */
/*   Updated: 2023/06/06 16:34:18 by aleespin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

int	size_of_r(int num, int size_n)
{
	if (num == 0)
	{
		return (size_n);
	}
	else
	{
		num = num / 10;
		return (size_of_r(num, size_n + 1));
	}
}

int	divider(int size_num)
{
	int	div;

	div = 1;
	while (size_num > 1)
	{
		div = div * 10;
		size_num--;
	}
	return (div);
}

void	ft_putnbr(int nb)
{
	int		size_num;
	int		div;
	int		aux;

	aux = 0;
	if (nb == 0)
	{
		putchar(nb + '0');
	}
	if (nb < 0)
	{	
		if (nb == -2147483648)
		{
			write(1, "-2147483648", 11);
		}
		else
		{
			nb = nb * -1;
			ft_putchar('-');
		}
	}

	if (nb != -2147483648)
	{
		/*size_num = size_of(nb);*/
		size_num = size_of_r(nb, 0);

		div = divider(size_num);
		while (size_num > 0)
		{
			aux = (nb / div) + '0';
			ft_putchar(aux);
			size_num--;
			nb = nb % div;
			div = div / 10;
		}
	}
}
